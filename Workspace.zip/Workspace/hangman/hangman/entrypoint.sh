#!/bin/ash

echo "Buscando archivos estaticos"
python manage.py collectstatic

echo "Aplicando cambios a la base de datos"
python manage.py makemigrations

echo "Aplicando migraciones a la base de datos"
python manage.py migrate --run-syncdb



exec "$@"