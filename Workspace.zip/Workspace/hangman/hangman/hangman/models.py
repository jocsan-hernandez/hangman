#Importamos de django para crear la base de datos en forma de modelos
from django.db import models

#Creamos un modelo llamado dificultad para asegurar la unificación
class Dificultad(models.Model):
    Dificultad= models.CharField('Dificultad', max_length=20, unique=True)

    def __str__(self):
        return self.Dificultad

#Creamos cada entidad de la base de datos obviando llaves primarias
class Palabra(models.Model):
    idPalabra= models.BigAutoField(primary_key=True)
    Palabra= models.CharField('Palabra', max_length=50, unique=True)
    Dificultad= models.ForeignKey(Dificultad, blank=False, null=False, on_delete=models.DO_NOTHING)


#Decidiendo como se verá nuestro modelo en el área de administración
    def __str__(self):
        return self.Palabra

#Modelo de usuarios
class Usuarios(models.Model):
    idUsuario=models.BigAutoField(primary_key=True)
    Nombre= models.CharField('Nombre Completo', max_length=100)
    Puntaje= models.IntegerField('Puntaje actual')

    def __str__(self):
        return self.Nombre

#Modelo de login
class Login(models.Model):
    nombreUsuario= models.CharField('Nombre de Usuario', max_length=50, unique=True)
    idUsuario=models.ForeignKey(Usuarios, on_delete=models.DO_NOTHING)
    Password= models.CharField(max_length=100)    

    def __str__(self):
        return self.nombreUsuario

#Modelo de intentos
class Intentos(models.Model):
    idUsuario=models.ForeignKey(Usuarios, on_delete=models.DO_NOTHING)
    idPalabra=models.ForeignKey(Palabra, on_delete=models.DO_NOTHING)
    letrasUsadas=models.CharField('Letras utilizadas', max_length=28)

    def __str__(self):
        return self.letrasUsadas
