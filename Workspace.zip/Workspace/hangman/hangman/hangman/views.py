#Necesitamos importar la librería que muestra HTML
from django.shortcuts import render, redirect
#Necesitamos una librería para manejar mensajes de error
from django.contrib import messages
#Necesitamos una librería para encriptar las contraseñas
import hashlib
#Necesitamos nuestros modelos de usuario
from .models import Login
from .models import Usuarios
from .models import Palabra
from .models import Intentos

def almacenar_letra(request, letra):
    victoria=False
    derrota=False
    #Primero veremos si tiene algun intento activo
    userio= Login.objects.filter(nombreUsuario=request.session['usuario'])
    enIntento= Intentos.objects.filter(idUsuario=userio.get().idUsuario)
    if(enIntento):
        palabra=enIntento.get().idPalabra
        errores=0
        aciertos=0
        for l in enIntento.get().letrasUsadas:
            if(l not in str(palabra.Palabra)):
                errores+=1
            #Tenemos que manejar los aciertos de forma diferente
        for l in palabra.Palabra:
            if (l in enIntento.get().letrasUsadas):
                aciertos+=1
            #Finalmente manejamos victoria o derrota según errores o aciertos, si tiene 5 errores pierde, si 
            #Acierta todas las letras gana
        if(errores==5):
            derrota=True
        if(aciertos==len(palabra.Palabra)):
            victoria=True           
    
        
  
    #Si alguien intenta ingresar sin estar logueado, entonces debe regresarlo al login
    if(not request.session['logged_in']):
        return redirect('login')
    #Se almacenara la letra en el intento
    userID= Login.objects.filter(nombreUsuario=request.session['usuario'])
    intento= Intentos.objects.filter(idUsuario=userID.get().idUsuario).get()
    if(letra.lower() in intento.letrasUsadas or (victoria or derrota)):
        pass
    else:
        intento.letrasUsadas+=letra.lower()
        intento.save()
    return redirect('ahorcado', request.session['usuario'], '?')

#definimos una funcion home que mostrara nuestro index
def home(request, name="Usuario"):
    #Regresamos una página a petición y un diccionario de contexto
    #Verificaremos si el usuario está logueado o no
    try:
        name=request.session['usuario']
        logged=request.session['logged_in']
        return render(request, 'index.html',{"name":name, "logged":logged})
    except:
        return render (request, 'index.html', {"name":name, "logged":False})

#definimos una funcion login que muestre el login
def login(request):
    #Vamos a verificar si están visitando la página o llenando la forma
    if request.method=="POST":
        usuario=request.POST['userName']
        contra=request.POST['pass']
        #declaramos una palabra secreta como sal
        salt = "hangman"
        # Lo añadimos al cifrado
        contra = contra+salt
        # Encodeamos la contraseña para comparar
        contra = hashlib.md5(contra.encode())
        #Finalmente como nuestra contraseña se guarda en hexadecimal, la convertimos a eso
        contra=contra.hexdigest()
        #Vemos si el usuario existe
        usuario= Login.objects.filter(nombreUsuario=usuario)
        if usuario:
            #Si el usuario existe ahora debemos comparar la contraseña
            if(contra==usuario.get().Password):
                name=usuario.get().nombreUsuario
                request.session['logged_in']=True
                request.session['usuario']=name
                return redirect('juego', name)
            else:
                messages.success(request, "Contraseña incorrecta")
                return redirect('login')
        else:
            messages.success(request, "Usuario no existe")
            return redirect('login')
    else:
        return render(request, 'login.html', {"name":request.session['usuario']})
    
def juego(request, name="Usuario"):
    try:   
          #veremos si tiene un intento, si lo tiene lo redirigimos a él
        userID= Login.objects.filter(nombreUsuario=request.session['usuario'])
        intento= Intentos.objects.filter(idUsuario=userID.get().idUsuario)
        if(intento):
            return redirect('ahorcado', name, '?')
        if request.method=="POST":
            return redirect('ahorcado', name, request.POST["dificultad"])
        if (request.session['logged_in'] and request.session['usuario']==name):
            return render(request, 'juego.html', {"name":name, "logged":request.session['logged_in']})    
        else:
            return redirect('login')
    except:
        return redirect('login')    

#Funcion para desloguearse       

def logout(request):
    request.session['logged_in']=None
    request.session['usuario']=None
    return redirect('login') 

#Funcion que va a manejar el signup
def signup(request):
    if request.method=="POST":
        #Primero vamos a verificar que el usuario no exista
        userName= request.POST["userName"]
        usuario= Login.objects.filter(nombreUsuario=userName)
        if usuario:
            messages.success(request,"Este usuario ya existe, intenta con otro")
            return redirect('signup')
        else:
            #Ahora debemos verificar si las contraseñas coinciden
            if(request.POST["pass1"]!=request.POST["pass2"]):   
                messages.success(request, "Las contraseñas no coinciden, intenta de nuevo")
                return redirect('signup')
            else:
                #Si llega hasta acá debemos inscribir al usuario 
                newUser=Usuarios()
                newUser.Nombre=request.POST["nombre"]
                newUser.Puntaje=0
                newUser.save()
                #Una vez inscrito debemos crearle su login
                newLogin=Login()
                newLogin.nombreUsuario=userName
                contra=request.POST["pass1"]
                salt = "hangman"
                # Lo añadimos al cifrado
                contra = contra+salt
                # Encodeamos la contraseña para comparar
                contra = hashlib.md5(contra.encode())
                #Finalmente como nuestra contraseña se guarda en hexadecimal, la convertimos a eso
                contra=contra.hexdigest()
                newLogin.Password= contra
                newLogin.idUsuario=newUser
                #Guardamos el nuevo login
                newLogin.save()
                #Redirigimos al juego 
                request.session['logged_in']=True
                request.session['usuario']=userName
                return redirect('juego', userName)
    else:
        return render(request, 'signup.html',{"name":request.session['usuario']})
    
#Vamos a definir una funcion que maneje la lógica del juego
def ahorcado(request, name, dificultad="?"):
    victoria=False
    derrota=False
    #Primero vemos que el usuario loggueado sea el que va a jugar por cualquier error
    if(name==request.session['usuario']):
        #Vamos a definir las letras que se pueden usar
        letras= "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        #Primero veremos si tiene algun intento activo
        userID= Login.objects.filter(nombreUsuario=request.session['usuario'])
        intento= Intentos.objects.filter(idUsuario=userID.get().idUsuario)
        usuario= Usuarios.objects.filter(idUsuario=userID.get().idUsuario.idUsuario).get()
        if(intento):
            palabra=intento.get().idPalabra
            #Veamos cuantos errores y aciertos tiene
            #Empecemos por los errores
            errores=0
            aciertos=0
            for letra in intento.get().letrasUsadas:
                if(letra not in palabra.Palabra):
                    errores+=1
            #Tenemos que manejar los aciertos de forma diferente
            for letra in palabra.Palabra:
                if (letra in intento.get().letrasUsadas):
                    aciertos+=1
            #Finalmente manejamos victoria o derrota según errores o aciertos, si tiene 5 errores pierde, si 
            #Acierta todas las letras gana
            if(errores==5):
                derrota=True
            if(aciertos==len(palabra.Palabra)):
                victoria=True    
            return render(request, 'ahorcado.html', {"puntuacion":usuario.Puntaje,"victoria":victoria, "derrota":derrota,"aciertos":aciertos,"errores":errores,"name":name, "letras":list(letras), "palabra":list(palabra.Palabra), "logged":True, "letras_usadas":list(intento.get().letrasUsadas), "Dificultad":palabra.Dificultad})
        else:
            #Quiere decir que no tiene un intento activo y nos interesa guardarlo
            if dificultad=="Facil":
                dificultad=1
            elif dificultad=="Normal":
                dificultad=2
            else:
                dificultad=3        
            if name==request.session['usuario']:
                #Queremos que envie una palabra de la dificultad al azar
                palabra= Palabra.objects.filter(Dificultad=dificultad).order_by("?")[0]
                newIntento= Intentos()
                newIntento.idUsuario= Login.objects.filter(nombreUsuario=request.session['usuario']).get().idUsuario
                newIntento.idPalabra=palabra
                newIntento.letrasUsadas=''
                newIntento.save()
                return render(request, 'ahorcado.html', {"puntuacion":usuario.Puntaje,"name":name, "palabra":list(palabra.Palabra), "letras":list(letras), "logged":True, "letras_usadas":[]})    
            else:
                return redirect('login')
    else:
        return redirect('login')        
    

def fin_juego(request):
    try:
        victoria=False
        derrota=False
        #Primero veremos si tiene algun intento activo
        userID= Login.objects.filter(nombreUsuario=request.session['usuario'])
        intento= Intentos.objects.filter(idUsuario=userID.get().idUsuario)
        if(intento):
            palabra=intento.get().idPalabra
            #Veamos cuantos errores y aciertos tiene
            #Empecemos por los errores
            errores=0
            aciertos=0
            for letra in intento.get().letrasUsadas:
                if(letra not in palabra.Palabra):
                    errores+=1
            #Tenemos que manejar los aciertos de forma diferente
            for letra in palabra.Palabra:
                if (letra in intento.get().letrasUsadas):
                    aciertos+=1
            #Finalmente manejamos victoria o derrota según errores o aciertos, si tiene 5 errores pierde, si 
            #Acierta todas las letras gana
            if(errores==5):
                derrota=True
            if(aciertos==len(palabra.Palabra)):
                victoria=True   

            #Si gana o pierde acaba el juego, se debe borrar el intento y cambiar la puntuación
            if (victoria or derrota):
                intento.delete()    
                #Actualiza puntuacion
                usuario= Usuarios.objects.filter(idUsuario=userID.get().idUsuario.idUsuario).get()
                if victoria:
                    if(str(palabra.Dificultad)=="Facil"):
                        usuario.Puntaje+=5
                    elif(str(palabra.Dificultad)=="Normal"):
                        usuario.Puntaje+=10
                    else:
                        usuario.Puntaje+=20 
                else:
                    if(str(palabra.Dificultad)=="Facil"):
                        usuario.Puntaje-=5
                    elif(str(palabra.Dificultad)=="Normal"):
                        usuario.Puntaje-=10
                    else:
                        usuario.Puntaje-=20    
                usuario.save()   
                return redirect('juego', request.session['usuario'])      
    except:
        return redirect('login')    

def puntuaciones(request):
    lista1=Usuarios.objects.order_by("-Puntaje").all()[0:20]
    lista=[]
    for usuario in lista1:
        lista.append([Login.objects.filter(idUsuario=usuario.idUsuario).get(), usuario.Nombre, usuario.Puntaje])
    return render(request, 'puntuaciones.html', {"lista":lista, "logged":request.session['logged_in'], "name":request.session['usuario']})        