from django.contrib import admin
#Importamos nuestros modelos al área de admin
from .models import *

#admin.site.register(Palabra)
admin.site.register(Dificultad)
admin.site.register(Intentos)
admin.site.register(Usuarios)
admin.site.register(Login)

@admin.register(Palabra)
class adminPalabra(admin.ModelAdmin):
    list_display=('idPalabra', 'Palabra', 'Dificultad')
    ordering=('idPalabra',)
    search_fields=('Palabra', 'Dificultad')
    list_filter=('Dificultad',)